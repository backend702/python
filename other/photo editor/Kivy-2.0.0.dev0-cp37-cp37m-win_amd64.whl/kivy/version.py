# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '2.0.0.dev0'
__hash__ = '2a7513e4dca83242ba908d3972c02f5b6eb778d1'
__date__ = '20190808'
